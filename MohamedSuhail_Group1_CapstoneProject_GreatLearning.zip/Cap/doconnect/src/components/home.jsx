import React from 'react';
import { Container, Typography, Box } from '@material-ui/core';
import './home.css';
import qna from '../Assets/images/qna.jpg';



const Home = () => {
    return(
    <Container maxWidth="">

        <Box className='body1' my={0}>
            <Typography className='wrapper'>
                <h2 id="bbb">DoConnect</h2>
                <div >
                <center id="aaa"><img src={qna} className="App-logo" alt="img" /></center>
            </div>
        </Typography>
    </Box>
</Container>
             
    )
}
export default Home;