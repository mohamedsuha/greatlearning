
import React from 'react';
import { AppBar, makeStyles, Toolbar } from '@material-ui/core';
import { NavLink } from 'react-router-dom';
import './style.css';

const useStyles = makeStyles({
    header: {
        backgroundColor: '#212121',
    },
    spacing: {
        paddingLeft: 20,
        color: '#fff',
        fontSize: '18px',
        textDecoration: 'none',
    }, 
    spacings:{
        marginLeft:'2%',
    },
    space:{
        paddingLeft: '60%',
    }
});
//user navigation bar
const UserNavbar = () => {
    const classes = useStyles();
    return (
        //creating navlinks for the user operations
        <AppBar className={classes.header} position="static">
            <Toolbar >

            <NavLink to="/userqa" className={classes.spacing}>Question Search</NavLink>

            <NavLink to="/UserAskedQuestion" className={classes.spacing}>Ask Question</NavLink>
            <NavLink to="/question" className={classes.spacing}>View Q&A</NavLink>

             <NavLink to="/aschat" className={classes.space}>     
            <button> Chat </button>
                </NavLink> 
            
            <NavLink to="/" className={classes.spacings}>
                    <button> Logout </button>
            </NavLink>

            </Toolbar>
        </AppBar>
    )
}

export default UserNavbar;