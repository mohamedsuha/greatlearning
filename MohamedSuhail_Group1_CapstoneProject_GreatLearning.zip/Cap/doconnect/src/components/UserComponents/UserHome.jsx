import UserNavbar from './UserNavbar';
import UserQA from'./UserQA';
//import AddQA from './UserAskedQuestion';
import AddQuestion from './addQuestion';
import Chat from './Chat';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Question from './question';

function UserHome() {    //Admin home page display method
  return (
    <Router>
    <UserNavbar/>
    <Routes>
      <Route path="/userqa" element={<UserQA/>} ></Route>
      <Route path="/UserAskedQuestion" element={<AddQuestion/>} ></Route>
      <Route path="/aschat" element={<Chat/>}></Route>
      <Route path="/question" element={<Question/>}></Route>

    </Routes>
  </Router>
);
}

export default UserHome;



