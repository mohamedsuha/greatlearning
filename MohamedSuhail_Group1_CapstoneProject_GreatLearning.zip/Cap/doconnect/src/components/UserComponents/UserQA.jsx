import React, { useEffect, useState } from 'react';
import { Table, TableCell, TableRow, TableHead, TableBody, makeStyles } from '@material-ui/core';
import { getallqa } from '../../Service/QAservice';

const useStyle = makeStyles({
    table: {
        width: '80%',
        margin: '50px 100px 100px 140px',
    },
    thead: {
        '& > *': {
            background: '#000000',
            color: '#FFFFFF',
            fontSize: '16px'
        }
    },
    trow: {
        '& > *': {
            fontSize: '16px'
        }
    }
})

const UserQA = () => {

    const classes = useStyle();
const [search,setSearch]=useState('');
    const [qa, setqa] = useState([]);
    useEffect(() => {
        getQA();
    }, [])

    const getQA = async () => {
        const response = await getallqa();  
        console.log(response);
        setqa(response.data);
    }

   

    return (
    <div>
<center>

<br/>

<input  className={classes.trow} type="search" placeholder="Search…"

 inputprops={{ 'aria-label': 'search' }}

 style={{border:'2px solid red',padding:'15px'}}

 value={search} onChange = {(e) => setSearch(e.target.value)}/><br/>

</center>
       
        <Table className={classes.table}>
            <TableHead>
                <TableRow className={classes.thead}>
                    <TableCell>ID</TableCell>
                    <TableCell>Questions</TableCell>
                    <TableCell></TableCell>
                </TableRow>
            </TableHead>
            <TableBody>
            {

qa.filter( x => x.question.toLowerCase()

.includes(search.toLowerCase())).map( (data,index )=> {



return(

    <TableRow className={classes.trow} key={index} >

         <TableCell>{data.id}</TableCell>

         <TableCell style={{textAlign:"center"}}>{data.question}</TableCell>

   </TableRow>

)

})                

}
            </TableBody>
        </Table>
        </div>
    )
}

export default UserQA;
