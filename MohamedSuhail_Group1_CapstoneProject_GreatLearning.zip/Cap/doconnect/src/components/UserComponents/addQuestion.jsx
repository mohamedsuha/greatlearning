import {useEffect, useState} from 'react';
import React, { useRef } from "react";
import 'bootstrap/dist/css/bootstrap.css';
import { getQuestions } from "../../Service/question.service"
import {getAnswers} from "../../Service/question.service"
import {addquestion} from "../../Service/question.service"
function AddQuestion() {
    const [question,setQuestion] = useState([]);
    const [name,setName] = useState([]);
  const fileSubmitHandler = (event) => {
    event.preventDefault();
    let questionset = {
      question:question,
      name:name,
      status:"pending"
  }
  addquestion(questionset);
  window.location.reload();
}
    
  return (
    <div className="App">
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-md-4">
          <form onSubmit={fileSubmitHandler}>
  <div class="form-group">
    <br></br>
    <label for="exampleInputEmail1">User Name</label>
    <input type="text" class="form-control"  value={name} onChange={(event) => setName(event.target.value)} id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Username" />
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Question</label>
    <input type="text" class="form-control"  value={question} onChange={(event) => setQuestion(event.target.value)}     id="exampleInputPassword1" placeholder="Question" />
  </div><br></br>
  <button type="submit" class="btn btn-primary">Ask Question</button>&nbsp;&nbsp;
  <button type="cancel" class="btn btn-primary">Cancel</button>
</form>
          </div>
        </div>
      </div>
</div>
  );
  
}

export default AddQuestion;