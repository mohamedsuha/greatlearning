import React, { useEffect, useState } from 'react';
import { Container, Typography, FormControl, Input, Box, FormGroup, Button,FormLabel } from '@material-ui/core';

import { addchat,getallchat } from '../../Service/chatservice';
import { useNavigate } from 'react-router-dom';
const initialValue = {  
    username: "",
    messege: "",
   
}
const Chat = () => {  

    const [chat, setChat] = useState(initialValue);
    const { username, messege} = chat;

    const navigate = useNavigate();

    const onValueChange = (e) =>
    {
      //  console.log(e);
      // console.log(e.target.value);
        setChat({...chat, [e.target.name]: e.target.value});
       console.log(chat);
    }

    const addChatDetails = async () =>{
       await addchat(chat);
       alert("data is added succeessfully")
    }


//---------------------
const [chats, setChats] = useState([]);

useEffect(() => {
    getchats();
}, [])

const getchats = async () => {
    const response = await getallchat();

    for(let i=0 ; i<response.data.length ; i++)
    {
       
        {
            console.log(response.data[i]);
            setChats(response.data);
        }
    }
        
    }

//-------------

    return (

        <div>
        <Container maxWidth="sm">
            <Box my={5}>
                <Typography variant="h5" align="center" >Chat Box</Typography>
                <br/><br/>

                <FormGroup>

                    <FormControl>
                        <FormLabel>UserName</FormLabel>
                        <Input onChange={(e) => onValueChange(e)} name="username" value={username} />
                    </FormControl>
                        <br/>

                    <FormControl>
                        <FormLabel>Message</FormLabel>
                        <Input type='text' onChange={(e) => onValueChange(e)} name="messege" value={messege} />
                    </FormControl>
                        <br/>
                    <Box my={3}>
                        <Button variant="contained" onClick={() => addChatDetails()} color="primary" align="center">POST</Button>
                    </Box>

                </FormGroup>
            </Box>
        </Container>

           
        <div className='container mt-5'>
          <form >
              <table id="customers">
                <thead>
                        <tr> 
                            <th style={{'textAlign': 'center'}}>UserName</th> 
                            <th style={{'textAlign': 'center'}}>Message</th>
                        </tr>
                </thead>
                <tbody>
                    {
                         chats.map((data) => (
                            <tr>
                                 <td>{data.username}</td>
                                 <td>{data.messege}</td>
                            </tr>
                         ))
                    }
                </tbody>
              </table>
        </form>
      </div> 
   </div>      
    )
}


export default Chat;