import React, { useState } from 'react';
import { Container, Typography, FormControl, Input, Box, FormGroup, Button, FormLabel } from '@material-ui/core';
import { useNavigate } from 'react-router-dom';

const initialValue = {
    username: "",
    password: ""
}


//used to check the login
function UserLogin() {
    const [db, setDb] = useState(initialValue);
    const navigate = useNavigate();

    const onValueChange = (e) => {

        setDb({ ...db, [e.target.name]: e.target.value });
        console.log(db);
    }

    //login method
    async function userPresent(data) {
        let check_data = await fetch("http://localhost:8082/user/users");
        let check = await check_data.json();
        let flag = false;
        console.log(check);
        for (let i = 0; i < check.length; i++) {
            if (check[i].username === data.username && check[i].password === data.password) { //validating the user credentials
                flag = true;
                sessionStorage.setItem("user", JSON.stringify(check[i]));
            }
        }
        if (flag === true) {
            alert("Login success");  //alert after successful user login
            navigate("/userq");
        }
        else {
            alert("Please Enter corect username and password")  //alert after unsuccessful userlogin
        }
    }
    return (

        //User login form
        <Container maxWidth="sm">
            <Box my={5}><br></br>
                <Typography variant="h5" align="center">User Login</Typography>
                <br/>
                <FormGroup>
                    <FormControl>
                        <FormLabel> Enter the username</FormLabel>
                        <Input onChange={(e) => onValueChange(e)} name="username" value={db.username} />
                    </FormControl>
                    <br/>
                    <FormControl>
                    <FormLabel> Enter the password</FormLabel>
                        <Input onChange={(e) => onValueChange(e)} name="password" value={db.password} type="password" />
                    </FormControl>
                    <Box my={3}><br></br>
                        <Button variant="contained" onClick={() => userPresent(db)} color="primary" align="center">Login</Button>
                        <Button onClick={() => navigate("/user")} variant="contained" color="secondary" align="center" style={{ margin: '0px 20px' }}>Cancel</Button> 
                        <br></br><br></br>
                        If You Don't have credentials please click here <Button variant="contained" onClick={() => navigate("/user-register")} color="primary" align="center">Registration</Button>
                    </Box>
                </FormGroup>
            </Box>
        </Container>

    )

}
export default UserLogin;
// 