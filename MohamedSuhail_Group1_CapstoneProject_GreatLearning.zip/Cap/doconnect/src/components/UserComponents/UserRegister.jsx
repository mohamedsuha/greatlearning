import React, { useState } from 'react';
import { Container, Typography, FormControl, InputLabel, Input, Box, FormGroup, Button } from '@material-ui/core';
import { addUser } from '../../Service/userservice';
import { useNavigate } from 'react-router-dom';

const initialValue = {    //declaring the initial values for user details
    name: "",
    username: "",
    password: "",
    email: "",
    phone: "",
}

const UserRegister = () => {    //user registration method

    const [user, setUser] = useState(initialValue);
    const { name, username, password, email, phone } = user;

    const navigate = useNavigate();

    const onValueChange = (e) => {
        //  console.log(e);
        // console.log(e.target.value);
        setUser({ ...user, [e.target.name]: e.target.value });
        console.log(user);
    }

    const addUserDetails = async () => {
        await addUser(user);
        alert("User Register Successfully")
       // window.open('/user-login');
        navigate('/user-login');
    }

    return (

        //User registration form
        
        <Container maxWidth="sm">
            <Box my={5}><br></br>
                <Typography variant="h5" align="center">User Registration Form</Typography>
                <FormGroup>
                    <FormControl>
                        <InputLabel>Name</InputLabel>
                        <Input onChange={(e) => onValueChange(e)} name="name" value={name} />
                    </FormControl>
                    <FormControl>
                        <InputLabel>User Name</InputLabel>
                        <Input onChange={(e) => onValueChange(e)} name="username" value={username} />
                    </FormControl>
                    <FormControl>
                        <InputLabel>Password</InputLabel>
                        <Input onChange={(e) => onValueChange(e)} name="password" value={password} />
                    </FormControl>
                    <FormControl>
                        <InputLabel>Email address</InputLabel>
                        <Input onChange={(e) => onValueChange(e)} name="email" value={email} />
                    </FormControl>
                    <FormControl>
                        <InputLabel>Phone Number</InputLabel>
                        <Input onChange={(e) => onValueChange(e)} name="phone" value={phone} />
                    </FormControl><br></br>
                    <Box my={3}>
                        <Button variant="contained" onClick={() => addUserDetails()} color="primary" align="center">Register</Button>
                        <Button onClick={() => navigate.push("/all")} variant="contained" color="secondary" align="center" style={{ margin: '0px 20px' }}>Cancel</Button>
                        <br></br><br></br>
                        Already Registered ? Please Login <Button variant="contained" onClick={() => navigate("/user-login")} color="primary" align="center">Login</Button>

                    </Box>
                </FormGroup>
            </Box>
        </Container>
    )
}


export default UserRegister;