import {useEffect, useState} from 'react';
import React, { useRef } from "react";
import 'bootstrap/dist/css/bootstrap.css';
import { getQuestions } from "../../Service/question.service"
import {getAnswers} from "../../Service/question.service"
import {addquestion} from "../../Service/question.service"
import {activeQuestion} from "../../Service/question.service"
import {activeAnswer} from "../../Service/question.service"
import axios from 'axios';
import { useNavigate } from "react-router-dom";
function Admin() {
    const [questions,setQuestions] = useState([]);
    const [answers,setAnswers] = useState([]);
    const navigate = useNavigate();
    useEffect(() => {
        console.log("from useEffect");
        const question = JSON.stringify({ name: 'John Doe' ,question:'how are you',status:'pending'});
        const answer = JSON.stringify({ name: 'John Doe' ,question:'how are you',answer:'fine',status:'pending'});
        getQuestions()
        .then((quesres) => quesres)
        .then((quesdata) => setQuestions(quesdata.data))
        getAnswers()
        .then((ansres) => ansres)
        .then((ansdata) => setAnswers(ansdata.data))
    },[])
    const activeQues= (id) => {
      activeQuestion(id);  window.location.reload();    
    }
    const activeAns= (id) => {
        activeAnswer(id);  window.location.reload();    
      }
  return (
    <div className="App">
      <div className="container">
        <div className="row justify-content-center">
       <h3 className='text-success text-center'> Active Questions & Answer</h3>
        {questions ?(
questions.map((question) =>{
return question.status  === 'Active' ? (

<div class="col-md-3 mb-5"   key={question.id}>
<div class="card w-100 h-100" >
  <div class="card-body">
    <p className='card-heading'>Question No: {question.id} </p>
    <h3 class="card-text text-danger">{question.question}</h3>
    <h6 className='card-heading'>Answers</h6>
    {answers.map((element, index) => {
        if (element.question === question.question && element.status === 'Active') {
          return <li key={index} className="text-success"><img src={element.url} alt="" className='img-fluid' />{element.answer}</li>;
        }
      })} 
     
      </div>
      </div>
</div>
) : (null);
}
)):(null)}
        </div>
      </div>


      <div className="container">
        <div className="row justify-content-center">
       <h3 className='text-success text-center'> Pending Questions</h3>
        {questions ?(
questions.map((question) =>{
return question.status  === 'pending' ? (
<div class="col-md-3 mb-5"   key={question.id}>
<div class="card w-100 h-100" >
  <div class="card-body">
    <p className='card-heading'>Question No: {question.id} </p>
    <h3 class="card-text text-danger">{question.question}</h3>
    <a onClick={() => { activeQues(question.id) }} className="btn btn-danger">Click To Active Question</a>
      </div>
      </div>
</div>
) : (null);
}
)):(null)}
        </div>
      </div>
      {/* <img src="../img/wifi.PNG"/> */}
      <div className="container">
        <div className="row justify-content-center">
       <h3 className='text-success text-center'> Pending Answers</h3>
       {answers ?(
answers.map((answer) =>{
return answer.status  === 'pending' ? (
<div class="col-md-3 mb-5"   key={answer.id}>
<div class="card w-100 h-100" >
  <div class="card-body">
    <p className='card-heading'>Question No: {answer.id} </p>
    <h3 class="card-text text-danger">{answer.question}</h3>
    <h6 class="card-text text-danger">{answer.answer}</h6>
  
    <img src={answer.url} alt="" className='img-fluid' />
    <h6 class="card-text text-danger">{answer.status}</h6>
    <a onClick={() => { activeAns(answer.id) }} className="btn btn-danger">Click To Active Answer</a>
      </div>
      </div>
</div>
) : (null);
}
)):(null)}
        </div>
      </div>
</div>
  );
  
}

export default Admin;