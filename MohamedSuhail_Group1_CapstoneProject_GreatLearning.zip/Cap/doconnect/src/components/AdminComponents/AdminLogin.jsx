import React, { useState } from 'react';
import { Container, Typography, FormControl, Input, Box, FormGroup, Button, FormLabel } from '@material-ui/core';
import { useNavigate } from 'react-router-dom';

const initialValue = {
    username: "",
    password: ""
}



//used to check the login
function AdminLogin() {
    const [db, setDb] = useState(initialValue);
    const navigate = useNavigate();

    const onValueChange = (e) => {

        setDb({ ...db, [e.target.name]: e.target.value });
        console.log(db);
    }

    //login method
    async function AdminPresent(data) {
        let check_data = await fetch("http://localhost:8081/admin/admins");
        let check = await check_data.json();
        let flag = false;
        console.log(check);
        for (let i = 0; i < check.length; i++) {
            if (check[i].username === data.username && check[i].password === data.password) { //validating the user credentials
                flag = true;
                sessionStorage.setItem("admin", JSON.stringify(check[i]));
            }
        }
        if (flag === true) {
            alert("Login success");  //alert after successful admin login
            navigate("/adminq");
        }
        else {
            alert("Please Enter corect username and password")  //alert after unsuccessful admin login
        }
    }
    return (

        //Admin login form
        <Container maxWidth="sm">
            <Box my={5}><br></br>
                <Typography variant="h5" align="center">Admin Login</Typography>
                <br/>
                <FormGroup>
                    <FormControl>
                    <FormLabel> Enter the username</FormLabel>
                        <Input onChange={(e) => onValueChange(e)} name="username" value={db.username} />
                    </FormControl>
                    <br/>
                    <FormControl>
                    <FormLabel> Enter the password</FormLabel>
                        <Input onChange={(e) => onValueChange(e)} name="password" value={db.password} type="password" />
                    </FormControl><br></br>
                    <Box my={3}>
                        <Button variant="contained" onClick={() => AdminPresent(db)} color="primary" align="center">Login</Button>
                        <Button onClick={() => navigate("/admin")} variant="contained" color="secondary" align="center" style={{ margin: '0px 20px' }}>Cancel</Button>
                        <br></br><br></br>
                        If Don't have credential please click here <Button variant="contained" onClick={() => navigate("/admin-register")} color="primary" align="center">Registration</Button>
                    </Box>
                </FormGroup>
            </Box>
        </Container>

    )

}
export default AdminLogin;