import {useEffect, useState} from 'react';
import React, { useRef } from "react";
import ReactDOM from 'react-dom'
import 'bootstrap/dist/css/bootstrap.css';
import { getQuestions } from "../../Service/question.service"
import emailjs from '@emailjs/browser';
import {getAnswers} from "../../Service/question.service"
import {addanswer} from "../../Service/question.service"
import {sendEmails} from "../../Service/email.service"
import axios from 'axios';
import { useNavigate } from "react-router-dom";
function Question() {
  const [files, setFiles] = useState('');
  const [fileSize, setFileSize] = useState(true);
  const [fileUploadProgress, setFileUploadProgress] = useState(false);
  const [fileUploadResponse, setFileUploadResponse] = useState(null);
  const FILE_UPLOAD_BASE_ENDPOINT = "http://localhost:8082";
    const [questions,setQuestions] = useState([]);
    const [answers,setAnswers] = useState([]);
    const [useranswer,setUseranswer] = useState([]);
    const [userquestion,setUserquestion] = useState([]);
    const [answerbox,setAnswerbox] = useState(false);
    const [answerboxques,setAnswerboxques] = useState(false);
  const form = useRef();
  const navigate = useNavigate();
  const uploadFileHandler = (event) => {
    setFiles(event.target.files);
   };
    useEffect(() => {
        console.log("from useEffect");
        const question = JSON.stringify({ name: 'John Doe' ,question:'how are you',status:'pending'});
        const answer = JSON.stringify({ name: 'John Doe' ,question:'how are you',answer:'fine',status:'pending'});
        getQuestions()
        .then((quesres) => quesres)
        .then((quesdata) => setQuestions(quesdata.data))
        getAnswers()
        .then((ansres) => ansres)
        .then((ansdata) => setAnswers(ansdata.data))
    },[])
    const handleSubmit = event => {
      setFileSize(true);
       setFileUploadProgress(true);
       setFileUploadResponse(null);
      
        const formData = new FormData();

        for (let i = 0; i < files.length; i++) {
        
            formData.append(`files`, files[i])
        }
        
        console.log(files[0]);
var url=(files[0].name);
console.log("url"+url)
      console.log('handleSubmit ran');
      event.preventDefault(); // 👈️ prevent page refresh
  
      console.log('Question 👉️', userquestion);
      console.log('Answer 👉️', useranswer);
  let data = {
    question : userquestion,
    answer : useranswer,
    status : 'pending',
    name : 'suhail',
    url:'../img/'+url
  }
  emailjs.sendForm('service_hj9qox5', 'template_d5zty08', form.current, 'lIS58hfd59gwYQTvR')
  .then((result) => {
      console.log(result);
      
  }, (error) => {
      console.log(error.text);
  });

  const requestOptions = {
    method: 'POST',           
    body: formData
};
fetch(FILE_UPLOAD_BASE_ENDPOINT+'/upload', requestOptions)
    .then(async response => {
        const isJson = response.headers.get('content-type')?.includes('application/json');
        const data = isJson && await response.json();

        // check for error response
        if (!response.ok) {
            // get error message
            const error = (data && data.message) || response.status;
            setFileUploadResponse(data.message);
            return Promise.reject(error);
        }

       console.log(data);
       setFileUploadResponse(data.message); 
      })
      .catch(error => {               
          console.error('Error while uploading file!', error);
      });
  setFileUploadProgress(false);

  addanswer(data);
alert("Answer Added");

window.location.reload();
    };
    
    const setclkquestion = (que) => {
      console.log(que);
      setAnswerboxques(que);
      setAnswerbox(true);      
      setUserquestion(que);
    };
    function sayHello() {
      window.location.reload();    
    }

  return (
    <div className="App">
<div class="container mt-5">
    <h1 className='text-center mb-3 text-primary'>DoConnect App</h1>
<div class="row justify-content-center">
{questions ?(
questions.map((question) =>{
return question.status  === 'Active' ? (

<div class="col-md-3 mb-5"   key={question.id}>
<div class="card w-100 h-100" >
  <div class="card-body">
    <p className='card-heading'>Question No: {question.id} </p>
    <h3 class="card-text text-danger">{question.question}</h3>
    <h6 className='card-heading'>Answers</h6>
    {answers.map((element, index) => {
        if (element.question === question.question && element.status === 'Active') {
          return <li key={index} className="text-success"><img src={element.url} alt="" className='img-fluid' />{element.answer}</li>;
        }
      })} 
      <a onClick={() => {setclkquestion(question.question) }} className="btn btn-primary mt-4">Add Answer</a>
  {question.question === answerboxques &&

  <form  ref={form} onSubmit={handleSubmit} className="mt-3">    
    <a onClick={sayHello}>
      Click me!
    </a>
<input value={userquestion}
    name='question' class="form-control d-none" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Select Question" />
       <label>Enter Your Answer</label>
<input 
name='answer' onChange={(event) => setUseranswer(event.target.value)}  class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Answer" />
   <input className='mt-3 ' type="file"  multiple onChange={uploadFileHandler}/>    
        
        {!fileSize && <p style={{color:'red'}}>File size exceeded!!</p>}
        {fileUploadProgress && <p style={{color:'red'}}>Uploading File(s)</p>}
       {fileUploadResponse!=null && <p style={{color:'green'}}>{fileUploadResponse}</p>}
<button type='submit' 
   className='btn btn-success mt-3'>Submit</button>
    <a onClick={sayHello}  className='btn btn-danger mx-3 mt-3'>
      Close
    </a>
 </form>  
 }
      </div>
      </div>
</div>
) : (null);
}
)):(null)}
</div></div>
</div>
);
}
export default Question;