import React from 'react';
import { AppBar, makeStyles, Toolbar } from '@material-ui/core';
import { NavLink } from 'react-router-dom';

import './style.css';

const useStyles = makeStyles({
    header: {
        backgroundColor: '#212121',
    },
    spacing: {
        paddingLeft: 20,
        color: '#fff',
        fontSize: '18px',
        textDecoration: 'none',
    },
    spacings:{
        paddingLeft: '50%' ,
    }
});

const AdminNavbar = () => {
    const classes = useStyles();
    return (
        //creating the navlinks for the admin operations.
        <AppBar className={classes.header} position="static">
            <Toolbar >
                
                <NavLink to="/qa" className={classes.spacing}>All Questions</NavLink>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                
                <NavLink to="/approve"  >Approve Q&A</NavLink>
                <NavLink to="/"  className={classes.spacings}>
                    <button >Logout</button> 
                </NavLink>
                
            </Toolbar>
        </AppBar>
    )
}

export default AdminNavbar;