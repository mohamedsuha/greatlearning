import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import AdminNavbar from './AdminNavbar';
import AllQAs from './AllQAs';
import AddQA from './AddQA';
import Admin from './admin';
import Question from './question';


function AdminHome() {    //Admin home page display method
  return (

    //routing paths for admin operations
    <Router>
      <AdminNavbar/>
      <Routes>
        <Route path="/qa" element={<AllQAs/>}></Route>
        <Route path="/addqa" element={<AddQA/>}></Route>
        <Route path="/approve" element={<Admin/>}></Route>
        <Route path="/question" element={<Question/>}></Route>
        </Routes>
    </Router>
  );
}

export default AdminHome;

