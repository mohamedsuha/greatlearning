
import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './components/home';
import Navbar from './components/Navbar';
import UserRegister from './components/UserComponents/UserRegister';
import UserLogin from './components/UserComponents/UserLogin';
import UserHome from './components/UserComponents/UserHome';
import UserQA from './components/UserComponents/UserQA';
import AdminRegister from './components/AdminComponents/AdminRegister';
import AdminLogin from './components/AdminComponents/AdminLogin';
import UserNavbar from './components/UserComponents/UserNavbar';
import AddQA from './components/UserComponents/UserAskedQuestion';
import AdminNavbar from './components/AdminComponents/AdminNavbar';
import AllQAs from './components/AdminComponents/AllQAs';
import Chat from './components/UserComponents/Chat';
import AddQuestion from './components/UserComponents/addQuestion';
import Question from './components/UserComponents/question';
import Admin from './components/AdminComponents/admin';
function App() {
  return (
    
       <Router>
        <Navbar/>
      <Routes>
      <Route path='/' element={<Home/>}></Route>
      <Route path='/user-register' element={<UserRegister/>}></Route>
      <Route path='/user-login' element={<UserLogin/>}></Route>
      <Route path='/admin-register' element={<AdminRegister/>}></Route>
      <Route path='/admin-login' element={<AdminLogin/>}></Route>
      <Route path='user' element={<UserHome/>}></Route>
      <Route path="userq" element={<UserNavbar />} />  
     <Route path="userqa" element={<UserQA />} />
     <Route path="UserAskedQuestion" element={<AddQuestion />} />
     <Route path="adminq" element={<AdminNavbar />} />
    <Route path="/qa" element={<AllQAs/>}></Route>
    <Route path="/addqa" element={<AddQA/>}></Route>
    <Route path="/aschat" element={<Chat/>}></Route>
    <Route path="/question" element={<Question/>}></Route>
    <Route path="/approve" element={<Admin/>}></Route>
      </Routes>
    </Router>
  );
}

export default App;
