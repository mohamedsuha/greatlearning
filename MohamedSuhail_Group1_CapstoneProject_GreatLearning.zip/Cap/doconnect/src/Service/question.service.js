import axios from "axios";

const url = "http://localhost:8083/userquestion/userquestion";
const allUserQuestions = "http://localhost:8083/userquestion/userquestions";
const allAnswers = "http://localhost:8084/answer/answers";
const url1 = "http://localhost:8084/answer/answer";
const activeq= "http://localhost:8083/userquestion/questionactive/'+id";
// const activea ="http://localhost:8084/answer/answeractive/'+id";


export const getQuestions = async (id) => {
  id = id || '';
  return await axios.get(`${allUserQuestions}/${id}`);
}

export const getAnswers = async (id) => {
  id = id || '';
  return await axios.get(`${allAnswers}/${id}`);
}

// export const addanswer= (data) => {
//   var answer = JSON.stringify(data);
//   axios.post('http://localhost:8084/answer', answer,  {headers: {
//   'Content-Type': 'application/json'}
//   });
// }

export const addanswer = async (ansqa) => {
  return await axios.post(url1,ansqa);
}
// export const addquestion= (data) => {
//   var answer = JSON.stringify(data);
//   axios.post('http://localhost:8083/userquestion', answer,  {headers: {
//   'Content-Type': 'application/json'}
//   });
//   alert("new question added successfully")
// }
export const addquestion = async (userqa) => {
  return await axios.post(url,userqa);
}

export const activeQuestion= (id) => {
  axios.get('http://localhost:8083/userquestion/questionactive/'+id);
  alert("question active successfully")
}



export const activeAnswer= (id) => {
  axios.get('http://localhost:8084/answer/answeractive/'+id);
  alert("answer active successfully")
}

