import axios from 'axios';

const url = "http://localhost:8083/userquestion/userquestion";
const allUserQuestions = "http://localhost:8083/userquestion/userquestions";
const edit = "http://localhost:8083/userquestion/userquestion";

export const getallUserqa = async (id) => {
    id = id || '';
    return await axios.get(`${allUserQuestions}/${id}`);
}

export const getUserQuestion = async (id) => {
    id = id || '';
    return await axios.get(`${url}/${id}`);
}

export const addUserqa = async (userqa) => {
    return await axios.post(url,userqa);
}

export const editUserqa = async (id, userqa) => {
    return await axios.put(`${edit}/${id}`,userqa);
}


export const deleteUserqa = async (id) => {
    return await axios.delete(`${edit}/${id}`);
}