import axios from 'axios';

const url = "http://localhost:8084/answer/answer";
const allAnswers = "http://localhost:8084/answer/answers";
const edit = "http://localhost:8084/answer/answer";

export const getallAns = async (id) => {
    id = id || '';
    return await axios.get(`${allAnswers}/${id}`);
}

export const getAnswer = async (id) => {
    id = id || '';
    return await axios.get(`${url}/${id}`);
}

export const addAns= async (ans) => {
    return await axios.post(url,ans);
}

export const editAns = async (id, ans) => {
    return await axios.put(`${edit}/${id}`,ans);
}


export const deleteAns = async (id) => {
    return await axios.delete(`${edit}/${id}`);
}