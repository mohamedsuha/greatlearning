import axios from 'axios';


const url = "http://localhost:8082/chat/chat";
const allChat = "http://localhost:8082/chat/chats";





export const getallchat = async (id) => {
    id = id || '';
    return await axios.get(`${allChat}/${id}`);
}

export const addchat = async (chat) => {
    return await axios.post(url,chat);
}