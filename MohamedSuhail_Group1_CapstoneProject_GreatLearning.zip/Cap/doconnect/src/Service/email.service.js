import emailjs from '@emailjs/browser';
export const sendEmail = (email) => {
    console.log(email.answer + "new")
    emailjs.sendForm('service_9idc3lg', 'template_v6ih5ho', {userquestion : email.question,useranswer : email.answer}, 'lIS58hfd59gwYQTvR')
      .then((result) => {
          console.log(result.text);
      }, (error) => {
          console.log(error.text);
      });
  };