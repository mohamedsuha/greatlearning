import axios from 'axios';

const url = "http://localhost:8082/user/register";
const allUsers = "http://localhost:8082/user/users";
const edit = "http://localhost:8082/user/user";

export const getallUsers = async (id) => {
    id = id || '';
    return await axios.get(`${allUsers}/${id}`);
}

export const addUser = async (user) => {
    return await axios.post(url,user);
}

export const editUser = async (id, user) => {
    return await axios.put(`${edit}/${id}`,user);
}


export const deleteUser = async (id) => {
    return await axios.delete(`${edit}/${id}`);
}