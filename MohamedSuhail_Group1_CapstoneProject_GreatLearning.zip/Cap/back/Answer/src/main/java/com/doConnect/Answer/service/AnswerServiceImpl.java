package com.doConnect.Answer.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.doConnect.Answer.entity.Answer;
import com.doConnect.Answer.repository.AnswerRepository;

@Service
public class AnswerServiceImpl implements AnswerService{
	public AnswerRepository answerRepository;	
	public AnswerServiceImpl(AnswerRepository answerRepository) {
		super();
		this.answerRepository = answerRepository;
	}
	@Override
	public void saveAnswer(Answer answer) {
		answerRepository.save(answer);
	}
	@Override
	public List<Answer> findAllAnswers() {
		return answerRepository.findAll();
	}
}