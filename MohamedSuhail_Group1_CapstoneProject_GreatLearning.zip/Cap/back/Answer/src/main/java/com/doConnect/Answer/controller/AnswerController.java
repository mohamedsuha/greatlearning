package com.doConnect.Answer.controller;

import java.util.List;

import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.doConnect.Answer.entity.Answer;
import com.doConnect.Answer.repository.AnswerRepository;
import com.doConnect.Answer.service.AnswerService;

@RestController
@RequestMapping("/answer")
@CrossOrigin(origins = "http://localhost:3000")
public class AnswerController {
	private AnswerRepository answerRepository;
	private AnswerService answerService;
	public AnswerController(AnswerRepository answerRepository, AnswerService answerService) {
		this.answerRepository = answerRepository;
		this.answerService = answerService;
	}

@RequestMapping(value="/answer", method=RequestMethod.POST)
    public String answer(@RequestBody Answer answer,BindingResult result){
	System.out.println(answer.getName());
    answerService.saveAnswer(answer);
        return "success";
    }


@GetMapping(path = "/answers")
public  List<Answer>  getanswerList( Model model) {
	  return answerService.findAllAnswers();
}


@GetMapping("/answeractive/{id}")
public String showUpdateForm(@PathVariable("id") long id, Model model) {	 
   Answer Answer = answerRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid Product Id:" + id));
   model.addAttribute("answers", Answer);
       System.out.println(Answer.getQuestion());
       Answer.setStatus("Active");
       answerRepository.save(Answer);
	return "Success";
}
}