package com.doConnect.Answer.service;

import java.util.List;

import com.doConnect.Answer.entity.Answer;

public interface AnswerService {
    void saveAnswer(Answer answer);
    List<Answer> findAllAnswers();
}