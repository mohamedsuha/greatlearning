package com.doConnect.Admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.doConnect.Admin.entity.Admin;
import com.doConnect.Admin.repository.AdminRepository;
import com.doConnect.Admin.service.AdminService;

@RestController
@RequestMapping("/admin")
@CrossOrigin(origins = "http://localhost:3000")
public class AdminController {
	
	@Autowired
	AdminService adminser;
	
	@Autowired
	AdminRepository adminrepo;
	
	@PostMapping("/register")
    public Admin register(@RequestBody Admin admin) {
        return adminser.register(admin);
    }
	
	@PostMapping("/login")
	public String Login(@RequestBody Admin admin) {
		return adminser.Login(admin);
	}
	
	//fetching all the data
		@GetMapping("/admins")
		public List<Admin> getallAdmins() {
			return adminser.getallAdmins();
		}
		
		@PutMapping("/admin/{id}")
		public String updateAdmin(@PathVariable long id, @RequestBody Admin admin) {
			
			return adminser.updateAdmin(id, admin);
		}
		
		//deleting the data
		@DeleteMapping("/admin/{id}")
		public String deleteAdmin(@PathVariable long id) {
			
			return adminser.deleteAdmin(id);
		}

}
