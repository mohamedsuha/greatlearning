package com.doConnect.Admin.service;

import java.util.List;

import com.doConnect.Admin.entity.Admin;

public interface AdminService {
	public Admin register(Admin admin);
	public String Login(Admin admin);
	public String updateAdmin(long id, Admin admin);
    public String deleteAdmin(long id);
    public List<Admin> getallAdmins();

	

}
