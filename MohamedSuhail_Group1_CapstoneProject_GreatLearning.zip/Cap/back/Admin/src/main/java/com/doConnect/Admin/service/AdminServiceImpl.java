package com.doConnect.Admin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.doConnect.Admin.entity.Admin;
import com.doConnect.Admin.repository.AdminRepository;


@Service
public class AdminServiceImpl implements AdminService {
	
	@Autowired
	AdminRepository adminrepo;

	@Override
	public Admin register(Admin admin) {
		Admin a=adminrepo.save(admin);
		   return a;
	}

	@Override
	public String Login(Admin admin) {
		if(adminrepo.findByUsernameAndPassword(admin.getUsername(), admin.getPassword())!=null) {
    		return "valid valid";
    	}
    	else {
    		return "invalid admin";
    		}
	}

	@Override
	public String updateAdmin(long id, Admin admin) {
		for (Admin adminData : adminrepo.findAll()) {

			if (adminData.getId() == id) {

				admin.setId(id);
				adminrepo.save(admin);
				return "Data is updated ";
			}
		}
		return " Id not found";
	}

	@Override
	public String deleteAdmin(long id) {
		for (Admin adminData : adminrepo.findAll()) {

			if (adminData.getId() == id) {

				adminrepo.deleteById(id);
				return "Data is deleted successfully ";
			}
		}
		return " Id not found";
	}

	@Override
	public List<Admin> getallAdmins() {
		List<Admin> admins = adminrepo.findAll();
		return admins;
	}

}
