package com.doConnect.User.service;

import java.util.List;

import com.doConnect.User.entity.Chat;
public interface ChatService {
	public Chat insert(Chat chat);
	public List<Chat> getallChats();

}
