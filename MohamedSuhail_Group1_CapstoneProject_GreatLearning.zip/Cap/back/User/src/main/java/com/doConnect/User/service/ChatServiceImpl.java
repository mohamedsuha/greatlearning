package com.doConnect.User.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.doConnect.User.entity.Chat;
import com.doConnect.User.repository.ChatRepository;

@Service
public class ChatServiceImpl implements ChatService{
	@Autowired
	ChatRepository chatrepo;

	@Override
	public Chat insert(Chat chat) {
		Chat c=chatrepo.save(chat);
		   return c;
	}

	@Override
	public List<Chat> getallChats() {
		List<Chat> chats = chatrepo.findAll();
		return chats;
	}

}
