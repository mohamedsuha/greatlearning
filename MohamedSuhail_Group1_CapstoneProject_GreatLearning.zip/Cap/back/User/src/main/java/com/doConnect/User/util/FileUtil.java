package com.doConnect.User.util;

import java.nio.file.Path;
import java.nio.file.Paths;

public class FileUtil {
	
	private FileUtil() {
	    // restrict instantiation
	  }
	  public static final String folderPath =  "C:\\Users\\abeesha.k\\Capstone Project\\Cap\\doconnect\\public\\img\\";
	  public static final Path filePath = Paths.get(folderPath);

}
