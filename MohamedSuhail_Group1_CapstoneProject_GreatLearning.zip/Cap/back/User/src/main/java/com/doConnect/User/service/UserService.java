package com.doConnect.User.service;

import java.util.List;

import com.doConnect.User.entity.User;

public interface UserService {
	public User register(User user);
    public String Login(User user);
    public String updateUser(long id, User user);
    public String deleteUser(long id);
    public List<User> getallUsers();

}
