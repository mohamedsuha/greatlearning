package com.doConnect.User.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.doConnect.User.entity.User;
import com.doConnect.User.repository.UserRepository;



@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
    UserRepository userrepo;

	@Override
	public User register(User user) {
		User u=userrepo.save(user);
		   return u;
	}

	@Override
	public String Login(User user) {
		if(userrepo.findByUsernameAndPassword(user.getUsername(), user.getPassword())!=null) 
    	{
    		return "valid user";
    	}
    	else 
    	{
    		return "invalid user";
    	}
	}

	@Override
	public String updateUser(long id, User user) {
		for (User userData : userrepo.findAll()) {

			if (userData.getId() == id) {

				user.setId(id);
				userrepo.save(user);
				return "Data is updated ";
			}
		}
		return " Id not found";
	}

	@Override
	public String deleteUser(long id) {
		for (User userData : userrepo.findAll()) {

			if (userData.getId() == id) {

				userrepo.deleteById(id);
				return "Data is deleted successfully ";
			}
		}
		return " Id not found";
	}

	@Override
	public List<User> getallUsers() {
		List<User> users = userrepo.findAll();
		return users;
	}

}
