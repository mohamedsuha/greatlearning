package com.doConnect.User.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.doConnect.User.entity.Chat;
import com.doConnect.User.service.ChatService;

@RestController
@RequestMapping("/chat")
@CrossOrigin(origins = "http://localhost:3000")
public class ChatController {
	
	@Autowired
	ChatService chatser;
	
	@PostMapping("/chat")
	    public Chat insert(@RequestBody Chat chat) {
	        return chatser.insert(chat);
	    }

	@GetMapping("/chats")
	public List<Chat> getallChats() {
		return chatser.getallChats();
	}
}
