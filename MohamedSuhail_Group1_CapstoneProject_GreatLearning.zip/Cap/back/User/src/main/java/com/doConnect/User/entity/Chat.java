package com.doConnect.User.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="chat")
public class Chat {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id ;
	private String username;
	private String messege;
	
	public Chat() {
		// TODO Auto-generated constructor stub
	}

	public Chat(long id, String username, String messege) {
		super();
		this.id = id;
		this.username = username;
		this.messege = messege;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getMessege() {
		return messege;
	}

	public void setMessege(String messege) {
		this.messege = messege;
	}

	@Override
	public String toString() {
		return "Chat [id=" + id + ", username=" + username + ", messege=" + messege + "]";
	}
	
	

}
