package com.doConnect.Question.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.doConnect.Question.entity.Question;
import com.doConnect.Question.service.QuestionService;

@RestController
@RequestMapping("/question")
@CrossOrigin(origins = "http://localhost:3000")
public class QuestionController {
	
	@Autowired
	QuestionService questionser;
	
	@PostMapping("/question")
    public Question insert(@RequestBody Question question) {
        return questionser.insert(question);
    }
	
	@GetMapping("/questions")
	public List<Question> getallQuestions() {
		return questionser.getallQuestions();
	}
	
	@PutMapping("/question/{id}")
	public String updateQuestion(@PathVariable long id, @RequestBody Question question) {
		
		return questionser.updateQuestion(id, question);
	}
	
	//deleting the data
	@DeleteMapping("/question/{id}")
	public String deleteQuestion(@PathVariable long id) {
		
		return questionser.deleteQuestion(id);
	}

}
