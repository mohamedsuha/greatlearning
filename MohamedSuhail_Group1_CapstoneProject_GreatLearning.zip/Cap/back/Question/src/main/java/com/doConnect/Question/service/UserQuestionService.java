package com.doConnect.Question.service;

import java.util.List;

import com.doConnect.Question.entity.UserQuestion;

public interface UserQuestionService {
	public UserQuestion insert(UserQuestion userquestion);
	public String updateUserQuestion(long id, UserQuestion userquestion);
    public String deleteUserQuestion(long id);
    public List<UserQuestion> getallUserQuestions();

}
