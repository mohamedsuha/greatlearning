package com.doConnect.Question.service;

import java.util.List;

import com.doConnect.Question.entity.Question;


public interface QuestionService {
	public Question insert(Question question);
	public String updateQuestion(long id, Question question);
    public String deleteQuestion(long id);
    public List<Question> getallQuestions();

}
