package com.doConnect.Question.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.doConnect.Question.entity.UserQuestion;
import com.doConnect.Question.repository.UserQuestionRepository;

@Service
public class UserQuestionServiceImpl implements UserQuestionService{
	

	@Autowired
	UserQuestionRepository userquestionrepo;

	@Override
	public UserQuestion insert(UserQuestion userquestion) {
		UserQuestion uq=userquestionrepo.save(userquestion);
		return uq;
	}

	@Override
	public String updateUserQuestion(long id, UserQuestion userquestion) {
		for (UserQuestion uqueData : userquestionrepo.findAll()) {
			if (uqueData.getId() == id) {
				userquestion.setId(id);
				userquestionrepo.save(userquestion);
				return "Data is updated ";
			}
		}
		return "Id not found";
	}

	@Override
	public String deleteUserQuestion(long id) {
		for (UserQuestion uqueData : userquestionrepo.findAll()) {

			if (uqueData.getId() == id) {

				userquestionrepo.deleteById(id);
				return "Data is deleted successfully ";
			}
		}
		return " Id not found";
	}

	@Override
	public List<UserQuestion> getallUserQuestions() {
		List<UserQuestion> list = userquestionrepo.findAll();
		return list;
	}



}
