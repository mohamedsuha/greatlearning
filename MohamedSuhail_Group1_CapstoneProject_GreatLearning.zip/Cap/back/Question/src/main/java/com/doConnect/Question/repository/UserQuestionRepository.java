package com.doConnect.Question.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.doConnect.Question.entity.UserQuestion;

@Repository
public interface UserQuestionRepository extends JpaRepository<UserQuestion, Long>{
	List<UserQuestion> findByName(String name);
}
