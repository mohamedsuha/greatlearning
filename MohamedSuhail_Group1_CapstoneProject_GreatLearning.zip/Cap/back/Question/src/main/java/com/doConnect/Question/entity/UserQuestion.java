package com.doConnect.Question.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="userquestion")
public class UserQuestion {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String question;
	private String status;
	private String name;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	@Override
	public String toString() {
		return "UserQuestion [id=" + id + ", question=" + question + ", status=" + status + ", name=" + name + "]";
	}
	public UserQuestion(long id, String question, String status, String name) {
		super();
		this.id = id;
		this.question = question;
		this.status = status;
		this.name = name;
	}
	public UserQuestion() {
		// TODO Auto-generated constructor stub
	}

}
