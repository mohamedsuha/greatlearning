package com.doConnect.Question.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.doConnect.Question.entity.Question;
import com.doConnect.Question.repository.QuestionRepository;

@Service
public class QuestionServiceImpl implements QuestionService{
	
	@Autowired
	QuestionRepository questionrepo;

	@Override
	public Question insert(Question question) {
		Question q=questionrepo.save(question);
		return q;
	}



	@Override
	public String deleteQuestion(long id) {
		for (Question queData : questionrepo.findAll()) {

			if (queData.getId() == id) {

				questionrepo.deleteById(id);
				return "Data is deleted successfully ";
			}
		}
		return " Id not found";
	}

	@Override
	public List<Question> getallQuestions() {
		List<Question> list = questionrepo.findAll();
		return list;
	}



	@Override
	public String updateQuestion(long id, Question question) {
		for (Question queData : questionrepo.findAll()) {
			if (queData.getId() == id) {
				question.setId(id);
				questionrepo.save(question);
				return "Data is updated ";
			}
		}
		return "Id not found";
	}

}
