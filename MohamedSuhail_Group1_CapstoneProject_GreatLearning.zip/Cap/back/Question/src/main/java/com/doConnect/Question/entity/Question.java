package com.doConnect.Question.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="question")
public class Question {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String question;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	@Override
	public String toString() {
		return "Question [id=" + id + ", question=" + question + "]";
	}
	
	public Question() {
		// TODO Auto-generated constructor stub
	}
	public Question(long id, String question) {
		super();
		this.id = id;
		this.question = question;
	}
	
	
	

}
