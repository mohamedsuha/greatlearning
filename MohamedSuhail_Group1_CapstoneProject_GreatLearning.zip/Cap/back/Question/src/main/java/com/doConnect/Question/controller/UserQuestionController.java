package com.doConnect.Question.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.doConnect.Question.entity.UserQuestion;
import com.doConnect.Question.repository.UserQuestionRepository;
import com.doConnect.Question.service.UserQuestionService;


@RestController
@RequestMapping("/userquestion")
@CrossOrigin(origins = "http://localhost:3000")
public class UserQuestionController {
	
	@Autowired
	UserQuestionService userquestionser;
	
	@Autowired
	UserQuestionRepository userquestionrepo;
	
	@PostMapping("/userquestion")
    public UserQuestion insert(@RequestBody UserQuestion userquestion) {
        return userquestionser.insert(userquestion);
    }
	
	@GetMapping("/userquestions")
	public List<UserQuestion> getallUserQuestions() {
		return userquestionser.getallUserQuestions();
	}
	
	@PutMapping("/upuserquestion/{id}")
	public String updateUserQuestion(@PathVariable long id, @RequestBody UserQuestion userquestion) {
		
		return userquestionser.updateUserQuestion(id, userquestion);
	}
	
	//deleting the data
	@DeleteMapping("/userquestion/{id}")
	public String deleteUserQuestion(@PathVariable long id) {
		
		return userquestionser.deleteUserQuestion(id);
	}
	

@GetMapping(path = "/questionactive/{id}")
public String showUpdateForm(@PathVariable("id") long id, Model model) {	
	System.out.println("id +"+id);
   UserQuestion UserQuestion = userquestionrepo.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid Product Id:" + id));
   model.addAttribute("questions", UserQuestion);
       System.out.println(UserQuestion.getQuestion());
       UserQuestion.setStatus("Active");
       userquestionrepo.save(UserQuestion);
	return "Success";
}

 }
